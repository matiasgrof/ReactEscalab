import React, { useState } from 'react';
const Video = (props) => {
    // let estrellas = 0;
    const [estrellas, setEstrellas] = useState(0); 
    const valorar = () => {
        setEstrellas(estrellas+1);
    }
    return (
        <div className="video-container">
            <div className="video-image">
              <img src={props.thumbnail} alt={props.title} />
            </div>
            <div className="video-info">
              <h3>{props.title}</h3>
              <button onClick={valorar}>Valorar</button> {estrellas} estrellas
              <p>Upload date: {props.dateAdded}</p>
              <h4>Channel's Title: {props.channel}</h4>
              <p>{props.description}</p>
            </div>
        </div>
        );
}
export default Video;